# Giới thiệu

Created: January 18, 2023 9:56 AM
Reviewed: No

# Tài liệu

---

# Content

---

# Nội dung chính

---

- Môn này sẽ trình bày về các kỹ năng thực hiện nghiên cứu. Sau đó áp dụng các kỹ năng này vào một dự án cụ thể.
- Sẽ bao gồm các nội dung chính sau:
    1. Giới thiệu
    2. Nghiên cứu khoa học là gì?
    3. Tài liệu khoa học: Tìm hiểu về các search tài liệu khoa học, các nguồn tài liệu uy tín
    4. Cách xây dựng đề cương nghiên cứu
    5. Viết và trình bày bài báo KH
    6. Các vấn đề về đạo đức khi làm nghiên cứu KH

# Giới thiệu

---

- 5 yếu tố đang làm thay đổi thế giới, trong đó cần chú trọng một vài yếu tố để hướng các nghiên cứu của mình đến đó. Nếu hướng được các nghiên cứu về các yếu tố này, chắc chắn sẽ được chú trọng:
    - Sự gia tăng của các dòng kết nối mới. Trong đó, sự kết nối về dữ liệu đang tăng lên và là yếu tố chính
    - Các công nghệ đột phá

# Chúng ta cần làm gì

---

- Một vài câu hỏi cần lưu tâm:
    1. Tôi sinh ra để làm gì?
    2. Tôi là ai? Câu hỏi này thể hiện tầm nhìn và cần làm rõ bằng 3 câu hỏi nhỏ sau:
        - Trong quá khứ tối là ai?
        - Hiện tại tôi là ai?
        - `Tập trung`: Tương lai (5 năm, 10 năm nữa) tôi là ai? → `Mục tiêu dài hạn của bạn là gì?` → `Kế hoạch thực hiện mục tiêu`
        - Trả lời:
            - Mục tiêu dài hạn: Có thể vừa đi dạy vừa đi làm. Công việc liên quan đến nghiên cứu và triển khai các giải pháp liên quan đến machine learning
            - Kế hoạch thực hiện
                - Sẽ có những bản kế hoạch cụ thể cho từng giai đoạn. Ở đây, kế hoạch tập trung vào giai đoạn chuẩn bị.
                
                | Giai đoạn | Tên công việc | Kết quả cần đạt | Deadline |
                | --- | --- | --- | --- |
                | 1. Giai đoạn chuẩn bị  | 1.1. Học tiếng Anh | 58/90 PTE Academic. Không kỹ năng nào dưới 50 | 20/6/2023 |
                | Kết thúc giai đoạn này bằng việc đi du học Tiến sĩ tại Úc | 1.2. Viết báo nộp hội nghị | Submit paper hội nghị rank B (thời gian review từ 2-3 tháng) | 1/6/2023 |
                | Hạn chót của giai đoạn 1: Nếu như thành công, sẽ nhận được học bổng trước tết dương lịch 2024 | 1.3. Chuẩn bị phỏng vấn lại với giáo sư:
                - Đọc cuốn sách “Pattern recognition and machine learning” mà giáo sư gửi
                - Liên hệ để phỏng vấn lại khi đã có tiếng Anh và 2 paper nộp hội nghị | - Đọc xong các chương được chỉ định trong cuốn sách
                - Phỏng vấn và chọn được lĩnh vực nghiên cứu | 30/6/2023 |
                |  | 1.4. Làm đề cương dựa trên đề tài mà giáo sư cung cấp
                - Đọc các tài liệu mà giáo sư cung cấp để làm đề cương
                - Thực hiện đề cương
                - Bảo vệ đề cương | - Đọc hiểu các tài liệu
                - Làm xong đề cương
                - Bảo vệ thành công đề cương | 30/7/2023 |
                | 2. Giai đoạn học tiến sĩ | 2.1. Thực hiện các nghiên cứu khoa học để nộp journal theo hướng dẫn của giáo sư. Số lượng bài báo chia đều cho 3 năm | Các bài báo được nhận đăng ở các tạp chí uy tín | Đầu năm 2024 - Cuối năm 2027 |
                | 3. Giai đoạn sau tiến sĩ | 3.1. Làm việc tại Úc | - Tìm được công việc tại Úc
                - KIẾM TIỀN | 1/1/2028 - 30/12/2028 |
                |  | 3.2. Trở về Việt Nam vào năm 29 tuổi |  |  |
    3. Điều quan trọng nhất trong cuộc đời tôi là gì?
        - Trả lời câu hỏi này bằng cách vẽ 4 vòng tròn tượng trưng cho các yếu tố Công việc, Gia đình, Xã hội (các mối quan hệ), Bản thân (phát triển bản thân, chơi thể thao, giải trí)
        - Mỗi vòng tròn có bán kính là mức độ quan trọng của nó. Phần giao nhau giữa các vòng tròn thể hiện mức độ overlap của các yếu tố (i.e. công việc liên quan đến bản thân thì 2 vòng tròn này overlap với nhau)
        - Vẽ 4 vòng tròn này ở 2 dạng: Thực tế và Mong muốn
        - Trả lời:
            
            ![Untitled.drawio (1).png](Gio%CC%9B%CC%81i%20thie%CC%A3%CC%82u%209f76fbddbffa42b2965277566d3fb679/Untitled.drawio_(1).png)
            
            - Đánh trọng số (theo hạn mức 24h/ngày, sau đó scale về tỷ lệ phần trăm)
                
                
                |  | Thực tế (h/ngày) | Thực tế (%) | Mong muốn (h/ngày) | Mong muốn (%) |
                | --- | --- | --- | --- | --- |
                | Công việc | 10. Giao với gia đình 2h, giao với xã hội 3h | 42%. Giao với gia đình 8%, giao với xã hội 13% | 10. Giao với xã hội 10h | 42%. Giao với xã hội 42% |
                | Gia đình | 4. Giao với bản thân 2h | 17%. Giao với bản thân 8% | 5 | 21% |
                | Xã hội | 5. Giao với bản thân 1h | 21%. Giao với bản thân 4% | 10 | 42% |
                | Bản thân | 12 | 50% | 9 | 38% |
                |  |  | $sum = (42+17-8 +21 - 13) + (50-8) + (-4) \approx100\%$ |  | $sum = (42+42-42)+32+38\approx100\%$ |
            - Vẽ hình:
            
            → Thực tế:
            
            - Thời gian bị phân mảnh nhiều do thiếu kỹ năng quản lý thời gian
            - Thời gian cho bản thân cao nhưng sử dụng không hiệu quả
            - Thời gian cho xã hội rất ít và không mang lại nhiều lợi ích
            
            → Mong muốn:
            
            - Thu hẹp thời gian cho bản thân nhưng sử dụng hiệu quả hơn
            - Tăng thời gian cho gia đình và xã hội
            
            ![Biểu đồ phân bổ thời gian 1 ngày (mong muốn)](Gio%CC%9B%CC%81i%20thie%CC%A3%CC%82u%209f76fbddbffa42b2965277566d3fb679/Untitled-Page-2.drawio_(1).png)
            
            Biểu đồ phân bổ thời gian 1 ngày (mong muốn)
            
            ![Biểu đồ phân bổ thời gian 1 ngày (thực tế)](Gio%CC%9B%CC%81i%20thie%CC%A3%CC%82u%209f76fbddbffa42b2965277566d3fb679/Untitled-Page-2.drawio.png)
            
            Biểu đồ phân bổ thời gian 1 ngày (thực tế)
            
    4. Giá trị cốt lõi (core values) của tôi là gì?
        - A.k.a. Điều gì làm tôi khác biệt?
        - Giá trị cốt lõi là những giá trị bất biến với thời gian
        - Xác định được giá trị cốt lõi giúp xác định rõ hướng phát triển trong các thời kỳ nhất định hoặc tìm ra lối đi khi đang mất định hướng